Rails.application.routes.draw do
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
  
  # 1) define routes for sessions_controller
  resource :session, only: [ :new, :create, :destroy ]                         # ? why singluar session?
  # ? instructions mention singuar session?
  # resources autocreates paths- which HTTP Verb and Path correspond to the right controller method/action
  # :session = refers to sessions_controller.rb/class (file name of sessions_controller.rb, classname, and ":session" above in routes must have same pluralization!)

  # get 'session/new', to: 'session#new'
  # post 'session', to: 'session#create'
  # delete 'session/:id', to: 'session#destroy'
  # new_session   GET    /session/new(.:format)  session#new
  # session_index POST   /session(.:format)      session#create
  # session       DELETE /session/:id(.:format)  session#destroy

  resources :users, only: [:new, :create, :show]
end
