class CreateUsers < ActiveRecord::Migration[5.2]
  def change
    create_table :users do |t|
      t.string  :email, null: false                   # ?unique: true- how come we don't add this contraint here?- it would take forever (O(n)), so adding index makes it faster (OLogN?)
      t.string  :password_digest, null: false
      t.string  :session_token, null: false
    end
    add_index :users, :email, unique: true
    add_index :users, :session_token, unique: true    # ?can this be done on one line (8-9 combined)
  end
end
