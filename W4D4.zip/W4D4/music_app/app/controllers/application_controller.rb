class ApplicationController < ActionController::Base
  protect_from_forgery with: :exception                                         # protect against CSRF attacks

  helper_method :current_user, :signed_in?                                      # available in all views? - yes

  private                                                                       # these methods will be available to child classes (as long as they are not explicitly called on)
  def current_user                                                              # returns user object (based client's unique session cookie)
    @current_user ||= User.find_by_session_token(session[:session_token])       # lazy initialize, if @current_user nil, make it equal to User Obj 
    # User.find_by_session_token = an active record method same as:
    # User.find_by(session_token: session[:session_token])
    # session = like a cookie (hash-like)
    # session = keyword like params, predefined rails cookie
    # :session_token is not an inherent key in session, it is just one we are making, so be consistent in naming!!
  end

  def signed_in?                                                                # return boolean true if user is signed in
    !!current_user
    # ^above same as:
    # if current_user is nil, return false (bec. !nil = true, so !true = false)
    # if current_user is true, return true
  end

  def sign_in(user)                                                             # takes in a user obj
    @current_user = user                                                        # saves a little work when we call #current_user and it's already defined
    session[:session_token] = user.reset_session_token!  
    # we are resetting the hash-like session-cookie
    # User#method, called in sessions_controller.rb 
  end

  def sign_out
    current_user.try(:reset_session_token!)                                     # #current_user method being called, then calling
    # Obj.try( method_name )  takes in a symbol referring to a method name, #=> attempts to call method on obj (won't raise error like .send() if method_name undefined)
    session[:session_token] = nil                                               # ? why reset to nil
  end

  def require_signed_in!                                                        # like ensure that we are logged in (will need when we build band stuff)
    redirect_to new_session_url unless signed_in?
  end
end
