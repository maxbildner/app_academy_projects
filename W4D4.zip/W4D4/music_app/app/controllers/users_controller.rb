class UsersController < ApplicationController
  # def new
  #   @user = User.new
  # end
  # ^above same as below:
  def new                                                                       # method called after client clicks on a link to create a new user
    @user = User.new                                                            # creating a new user attr = user obj (ok to have no arguments, bec arg validations only occur when we try to save/modify db!)
    # want an instance @var so views has access to it
    render :new                                                                 # serve up file in views/users/new.html.erb
  end
  # need a folder for each controller

  def create                                                                    # this method is called after client ex. clicks on a submit form button to sign up a new user
    @user = User.new(user_params)                                               # create user attr = new user obj but with filtered params!!!!

    if @user.save                                                               # if user.save is successful, (i.e. client entered in correct password length & didn't leave email/pw fields blank)
      sign_in(@user)                                                            # method defined in ApplicationController
      redirect_to new_user_url                                                  # redirect client to login page (for now testing purposes)
      # to determine what path to put above^, find which controller method we want, then look at corresponding prefix (NOT URI pattern!)
    else                                                                        # failed to create new user in db
      flash.now[:errors] = @user.errors.full_messages                           # .errors.full_messages = an active record method that is an array of all errors
      # why not ['error message here'] like in sessions_controller.rb - bec. there could be multiple errors we want to display
      render :new                                                               
    end
  end

  private
  def user_params
    params.require(:user).permit(:password, :email)
  end
end