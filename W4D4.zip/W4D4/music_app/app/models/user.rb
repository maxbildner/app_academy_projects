# == Schema Information
#
# Table name: users
#
#  id              :bigint           not null, primary key
#  email           :string           not null
#  password_digest :string           not null
#  session_token   :string           not null
#

# write methods as you need them (ex. Findby, ispassword, password=, ... )
class User < ApplicationRecord
  # 1) Validations
  validates :email, :password_digest, :session_token, presence: true
  validates :password, { length: {minimum: 6}, allow_nil: true }    # ?allow_nil: true allows "server"/us to error out when we create a new user obj (User.new) or save to the db?
  # validates method takes in column name, and options hash (defines constraints)
  
  # 6)
  # after we initialize a new user obj, we want to ensure they have a session token (runs #ensure_session_token method below)
  after_initialize :ensure_session_token                            # can use either this or before_valid

  # class methods
  class << self
    # 3) F
    # User.find_by_credentials will be called in controllers/sessions_controller.rb to authenticate login
    def find_by_credentials(email, password)                        # takes in two strings, return user obj if password matches our hashed pw in db and user exists in db, return nil if email not found in db or password invalid
      user = User.find_by(email: email)                             # find user in our db. Class.find_by(takes in options hash), returns obj instance
      # return nil if user not found in db (i.e. user evauates to nil)
      # return user obj if arg password matches db session_session token, return false if password not correct
      bcrypt_obj = BCrypt::Password.new(user.password_digest)       # BCrypt::Password.new takes in a hashed/salted password string, returns a BCrypt Object instance
      user && bcrypt_obj.is_password?(password) ? user : nil        # BCrypt#is_password?(str) is an instance method called on a bcrypt obj, returns bo
      # return user obj if password matches our hashed pw in db and user exists in db, return nil if email not found in db or password invalid
    end

    def generate_session_token                                      # returns string of n-bytes of random chars
      SecureRandom.urlsafe_base64                                   # optional n arg, default n = 16
    end
  end

  # 2) setter and getter methods for password
  attr_reader :password
  def password=(password)                                           # setter method, takes in string, returns string hashed/salted version of string
    @password = password
    # sesion_token = BCrypt::Password.create(password)              # won't work! bec. session_token is local var
    # @sesion_token = BCrypt::Password.create(password)             # won't work! bec. @session_token is local instance var
    self.password_digest = BCrypt::Password.create(password)        # sets session_token attribute of user obj to hashed/salted version of string password arg
    # self = user obj instance w/ email, password_digest, session_token attributes
    # self.____ = active record setter method of objects attribute
  end

  # 4)
  def reset_session_token!                                  # resets suser obj (self's) session_token attribute, and returns that new session_token attr
    self.session_token = User.generate_session_token        # sets user obj (self's) session_token attribute to a random 16-byte str
    self.save!                                              # ?why save w/ !/error here? (good for debugging bec. #reset_session_token is used in other files)
    self.session_token                                    
  end

  # 5)
  def ensure_session_token                                  # if user obj (self) session_token attr is nil, reset it to one
    self.session_token ||= User.generate_session_token      # ? this is almost doing the same thing as reset_session_token
    # self.session_token will only be nil when the user is signing up (no session_token exists)
  end

  # def is_password?(password)                              # optional helper method
  # end



  # 6) need to create associations here


end
